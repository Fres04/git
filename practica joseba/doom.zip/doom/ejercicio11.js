document.getElementById('otro').addEventListener('click', function() {
    let texto = prompt('Por favor, ingrese su texto:');
    console.log(texto);
  });
  