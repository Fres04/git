<?php
$num =rand(10,100);
echo $num;