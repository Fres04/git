<?php
echo $_GET['num1']+$_GET['num2'];